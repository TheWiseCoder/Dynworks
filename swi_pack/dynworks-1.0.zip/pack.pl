% pack information for dynworks

name(dynworks).

title('Dynamic multi-dimensional arrays and vectors').

version('1.0').

author('GT Nunes', 'wisecoder01@gmail.com').

maintainer('GT Nunes', 'wisecoder01@gmail.com').

packager('GT Nunes', 'wisecoder01@gmail.com').

home('https://github.com/TheWiseCoder/Dynworks').

download('https://github.com/TheWiserCoder/Dynworks/swi-pack/*.zip').


